--- STEAMODDED HEADER
--- MOD_NAME: Othermod
--- MOD_ID: Othermod
--- MOD_AUTHOR: [Ai gen goku]
--- MOD_DESCRIPTION: somethings awaits !```
--- MOD_PREFIX: other
----------------------------------------------
------------MOD CODE -------------------------

-- made so that other mods in the other genre works

NFS.load(SMODS.current_mod.path.."Others/Othermod_Jokers.lua")()
NFS.load(SMODS.current_mod.path.."Others/Othermod_Tarots.lua")()
NFS.load(SMODS.current_mod.path.."Others/Othermod_Vouchers.lua")()
NFS.load(SMODS.current_mod.path.."Others/Othermod_Enhancements.lua")()
NFS.load(SMODS.current_mod.path.."Others/Othermod_Packs.lua")()

----------------------------------------------
------------MOD CODE END----------------------